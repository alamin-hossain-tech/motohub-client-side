# Project Name: MotoHub (A car Resale Website)

## [Live Site Link](https://motohub-53b37.web.app/).

### 1. This Project made with React App.

### 2. Tailwind framework based .

### 3. Material UI, Flowbite React Components used.

### 4. Add to wishlist feature implemented for product card.

### 5. Stripe Payment System integrated.

adminEmail: alamin@gmail.com

adminPassword: 123456789Ab
